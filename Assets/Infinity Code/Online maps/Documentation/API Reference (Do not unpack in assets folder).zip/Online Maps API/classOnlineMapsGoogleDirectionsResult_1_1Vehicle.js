var classOnlineMapsGoogleDirectionsResult_1_1Vehicle =
[
    [ "icon", "classOnlineMapsGoogleDirectionsResult_1_1Vehicle.html#ab1160b679fbe766ab865f6a25735ca32", null ],
    [ "local_icon", "classOnlineMapsGoogleDirectionsResult_1_1Vehicle.html#af8742aff21ee0b658461a3127b9252a9", null ],
    [ "name", "classOnlineMapsGoogleDirectionsResult_1_1Vehicle.html#afba861aaf6c7c26d63af332c6358de31", null ],
    [ "type", "classOnlineMapsGoogleDirectionsResult_1_1Vehicle.html#adfce0f4c67bc3332865b0cddaee5fc8b", null ]
];