var searchData=
[
  ['name',['name',['../classOnlineMapsXML.html#ad857405a402ace0bd845555b4a161413',1,'OnlineMapsXML']]],
  ['noderefs',['nodeRefs',['../classOnlineMapsOSMWay.html#aa5893ecacad115acb76a0866269f140a',1,'OnlineMapsOSMWay']]]
];
